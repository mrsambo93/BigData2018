package hw1.utils;

public class ColumnIndexes {
	public static final int ID = 0;
	public static final int PRODUCT_ID = 1;
	public static final int USER_ID = 2;
	public static final int PROFILE_NAME = 3;
	public static final int HELPFULNESS_NUMERATOR = 4;
	public static final int HELPFULNESS_DENOMINATOR = 5;
	public static final int SCORE = 6;
	public static final int TIME = 7;
	public static final int SUMMARY = 8;
	public static final int TEXT = 9;
}
